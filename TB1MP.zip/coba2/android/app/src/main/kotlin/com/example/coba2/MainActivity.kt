package com.example.coba2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
