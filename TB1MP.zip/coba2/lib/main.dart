import 'package:flutter/material.dart';
import 'detailpage.dart';
    
void main() {
  runApp(MaterialApp(
    title: "TUGAS FLUTTER",
    home: BelajarForm(),
  ));
}
    
class BelajarForm extends StatefulWidget {
  @override
  _BelajarFormState createState() => _BelajarFormState();
}
    
class _BelajarFormState extends State<BelajarForm> {
  final _formKey = GlobalKey<FormState>();
  final name = TextEditingController();
    
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Insert API Address"),
      ),
          // untuk membuat form input tambahakan widget form() 
      body: Form(
        // key adalah kunci unik untuk mengidentifikasi suatu form 
        // di bawah key ini tambahkan widget sesuai selera kalian
        key: _formKey,
        child: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            //agar semua widget diposisi kiri
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //textformfield digunakan untuk membuat widget form
              TextFormField(
                //memberikan identitas untuk setiap form
                controller: name,
                decoration: InputDecoration(
                  hintText: "Ketik alamat API",
                  labelText: "Api Address",
                ),
                //memberikan validasi jika form kosong
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Form tidak boleh kosong';
                  }
                  return null;
                },
              ),
                  //memberikan jarak
              SizedBox(height: 15),
                  //membuat button untuk mengirim dataw 
              ElevatedButton(
                child: Text(
                  "Submit",
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  //jika data lengkap maka kirim data ke halaman selanjutnya
                  if (_formKey.currentState!.validate()) {
                    Navigator.push(
                      context, 
                      MaterialPageRoute(
                        //name.text adalah parameter yang dikirim
                        //alamat.text adalah paramter yang dikirim
                        builder: (_) => DetailPage(name: name.text)
                      )
                    );
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}